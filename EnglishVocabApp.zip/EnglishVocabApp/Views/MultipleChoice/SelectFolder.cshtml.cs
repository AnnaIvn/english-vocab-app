using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EnglishVocabApp.Views.MultipleChoice
{
    public class SelectFolderModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
