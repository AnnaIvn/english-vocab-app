using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EnglishVocabApp.Views.Matching
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
