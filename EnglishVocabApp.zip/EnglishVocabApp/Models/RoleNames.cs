﻿namespace EnglishVocabApp.Models
{
    public struct RoleNames
    {
        public const string USER = "user";
        public const string ADMIN = "admin";
    }
}
